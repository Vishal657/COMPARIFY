export interface Filter {
  data: string;
  filter_id: number;
  filter_options: any;
}
