export interface Query {
  title: string;
  description: string;
}
