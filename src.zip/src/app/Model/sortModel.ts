export interface Sort {
  data: string;
  sort_id: number;
}
